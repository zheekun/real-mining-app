
const axios = require('axios');
module.exports = {
  sendInvoice: async (amountSat, memo) => {
    const res = await axios.post(process.env.LN_URL + '/invoice', {
      amount: amountSat,
      memo: memo
    });
    return res.data;
  }
};
