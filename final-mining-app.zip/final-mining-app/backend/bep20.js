
const Web3 = require('web3');
const web3 = new Web3(process.env.BSC_NODE);
const tokenContract = new web3.eth.Contract([
  // ABI Token Kosong (isi sesuai token)
], process.env.TOKEN_ADDRESS);

module.exports = tokenContract;
