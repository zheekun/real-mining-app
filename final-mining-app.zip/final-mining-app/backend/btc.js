
const Client = require('bitcoin-core');
const client = new Client({
  network: 'mainnet',
  username: process.env.BTC_USER,
  password: process.env.BTC_PASS,
  host: process.env.BTC_HOST,
  port: 8332
});
module.exports = client;
