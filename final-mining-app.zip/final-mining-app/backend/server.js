
const express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();
const app = express();
app.use(bodyParser.json());

const btc = require('./btc');
const ln = require('./lightning');
const bep20 = require('./bep20');

// Simulasi mining
app.post('/simulate-mining', async (req, res) => {
  const { address, network } = req.body;
  if (!address || !network) return res.status(400).send('Missing address or network');

  const reward = Math.random() * 0.0005;
  res.send({ status: 'ok', network, address, reward: reward.toFixed(8) });
});

// Cek koneksi ke node
app.get('/status', async (req, res) => {
  res.send({ status: 'online', networks: ['bitcoin', 'lightning', 'bep20'] });
});

app.listen(3000, () => console.log('✅ Server running on port 3000'));
