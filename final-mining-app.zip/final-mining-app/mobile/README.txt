Folder ini untuk source code Flutter/React Native aplikasi mining.
Silakan tempatkan source code UI di sini.