# Final Mining App

Proyek aplikasi mining nyata:
- Terhubung ke Bitcoin (RPC), Lightning (REST API), dan BEP-20 (BSC via Web3)
- Backend: Node.js
- Frontend: Flutter (masih kosong)
- Tidak ada iklan dan sistem kontrak
- Simulasi kecepatan mining hingga 50Th/s

## Jalankan Backend
```bash
cd backend
npm install
node server.js
```

## Jalankan Frontend
Buat UI di folder /mobile dengan framework Flutter atau React Native.
