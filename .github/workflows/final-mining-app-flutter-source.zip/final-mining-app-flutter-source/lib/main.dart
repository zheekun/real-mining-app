
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MiningApp());
}

class MiningApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Real Mining App',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: MiningHomePage(),
    );
  }
}

class MiningHomePage extends StatefulWidget {
  @override
  _MiningHomePageState createState() => _MiningHomePageState();
}

class _MiningHomePageState extends State<MiningHomePage> {
  double reward = 0.0;
  bool isMining = false;

  Future<void> startMining() async {
    setState(() {
      isMining = true;
    });

    final response = await http.post(
      Uri.parse('http://10.0.2.2:3000/simulate-mining'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'address': 'your_wallet_address_here',
        'network': 'bitcoin'
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        reward += double.tryParse(data['reward'].toString()) ?? 0.0;
      });
    }

    setState(() {
      isMining = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Real Mining App'),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Total Reward:', style: TextStyle(fontSize: 24)),
              SizedBox(height: 10),
              Text('$reward BTC', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: isMining ? null : startMining,
                child: isMining
                    ? CircularProgressIndicator(color: Colors.white)
                    : Text('Start Mining', style: TextStyle(fontSize: 20)),
              )
            ],
          ),
        ),
      ),
    );
  }
}
